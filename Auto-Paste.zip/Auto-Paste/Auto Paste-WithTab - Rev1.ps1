﻿$wshell = New-Object -ComObject wscript.shell;
$mylocation = Get-Location
$path = "$mylocation\SourceList.txt"
$stuff = Get-Content -Path $path
$length = $stuff.Length
$num = 0
echo "You have 45 seconds to get into the field that you need these items put into."
Sleep 35
echo "10 more seconds"
Sleep 10
echo "----------" "$length items to process"
for ($num ; $num -lt $length ; $num++){
    Sleep 1
    $wshell.SendKeys($stuff[$num])
    Sleep 1
    $wshell.SendKeys('{TAB}')
    Sleep -Milliseconds 500
    $wshell.SendKeys("~")
    $printtext1 = [string]($length-($num+1))
    $printtext2 = "Items remaining:"
    echo $printtext2$printtext1
}