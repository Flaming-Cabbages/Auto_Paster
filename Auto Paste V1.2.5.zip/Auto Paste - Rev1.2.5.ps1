﻿##Code by Flaming-Cabbages
$wshell = New-Object -ComObject wscript.shell;

$popup = $wshell.Popup("Does the program need to press tab?",0,"Choice",0x4)

if ($popup -eq 7){
    $mylocation = Get-Location
    $path = "$mylocation\SourceList.txt"
    $stuff = Get-Content -Path $path
    $length = $stuff.Length
    $num = 0
    echo "The program will not press TAB"
    echo "You have 35 seconds to get into the text field that you need these items pasted into."
    Sleep 25
    echo "10 more seconds..."
    Sleep 10
    echo "----------" "$length items to process" "----------"
    for ($num ; $num -lt $length ; $num++){
        Sleep 1
        $wshell.SendKeys($stuff[$num])
        Sleep 1
        $wshell.SendKeys("~")
        $printtext1 = [string]($length-($num+1))
        $printtext2 = "Items remaining:"
        echo $printtext2$printtext1
    }
    $wshell = New-Object -ComObject Wscript.Shell

    $popup = $wshell.Popup("Finished pasting!",0,"Pasting Complete!",0x0)
}
elseif ($popup -eq 6){
    $mylocation = Get-Location
    $path = "$mylocation\SourceList.txt"
    $stuff = Get-Content -Path $path
    $length = $stuff.Length
    $num = 0
    echo "The program will press TAB"
    Sleep 2
    echo "You have 35 seconds to get into the field that you need these items put into."
    Sleep 25
    echo "10 more seconds"
    Sleep 10
    echo "----------" "$length items to process" "----------"
    for ($num ; $num -lt $length ; $num++){
        Sleep 1
        $wshell.SendKeys($stuff[$num])
        Sleep 1
        $wshell.SendKeys('{TAB}')
        Sleep 1
        $wshell.SendKeys("~")
        $printtext1 = [string]($length-($num+1))
        $printtext2 = "Items remaining:"
        echo $printtext2$printtext1
    }
    $wshell = New-Object -ComObject Wscript.Shell

    $popup = $wshell.Popup("Finished pasting!",0,"Pasting Complete!",0x0)
}