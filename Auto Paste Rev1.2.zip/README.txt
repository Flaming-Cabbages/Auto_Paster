This is the second rendition of Auto Paste by Flaming-Cabbages.

How to use ---
First you need to know which one to use, this .zip now only has one .ps1 file included in it.
Both of the options that were available in the last version have been bundled together into the same file.
One of the options will paste the text then hit enter, the other will paste the text, hit tab, then hit enter.

1. To use the program, simply copy whatever table you need put into a area that doesn't accept tables
into the text file labled 'SourceList' then save the file. Ensure that each item is on a different
line, not all on the same line.
Correct		    Incorrect
   V		        V
text 1          text 1 text 2 text 3
text 2
text 3

2. After saving the file, find the powershell script, right click on it, and click 'Run With Powershell'

3. Once you click 'Run With Powershell' the program will ask you if you need it to press TAB or not,
After selecting the option that you need, the program will give you 45 seconds to click into the box
that you want the items pasted into, it will begin pasting after 45 seconds.


The purpose of this program is to provide a easy way to paste tables and lists into systems that
don't accept tables and lists. 

To know if you need to use the one with tab or not, you just need to check whether or not the box
that you are pasting into will allow you to type into it and then press enter to enter an item, or
whether it requires you to click on a button. If it requires you to click a button, use the one
with tab.

Is this probably not the best way to do this? I would think so